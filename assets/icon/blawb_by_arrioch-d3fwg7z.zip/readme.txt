Blawb icons for Android OS


RULES:
	- These icons are free for personal use on your device.
	- You can freely share them as long as you don't gain any commercial benefit from them.


COMING SOON:

	- more icons for more popular apps
	- ADW theme
	- GO Launcher theme
	- .psd template


CONTACT:

arrioch@gmail.com

Follow me on Twitter for more free icons @arrioch